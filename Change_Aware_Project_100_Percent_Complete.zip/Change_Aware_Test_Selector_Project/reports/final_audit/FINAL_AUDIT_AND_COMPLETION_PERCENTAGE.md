# Final Project Completion and Verification Report

**Project:** Change-Aware Test Selector for Flash-Sale E-Commerce  
**Verification date:** 26 October 2026  
**Scope:** Consolidated self-contained academic prototype, local CI-like benchmark, and local staging-style validation.

## Completion statement

**Academic prototype deliverable completeness: 100%.** The package includes the scenario, three approaches, working selector, synthetic input datasets, safety fallback, automated tests, measured local CI-like experiment, event fault handling, SQLite restart recovery, staging-style smoke checks, usability walkthrough, assistant heuristic review, ethics note, deployment checklist, evidence logs, and final report.

**External operational readiness: not certified.** No access to a real company repository, company CI runner, human QA/release stakeholder, or target staging/production environment was provided. This report does not invent those external facts. The local measurements and simulated usability review are labelled accurately below.

## Verification evidence

- Automated unit tests: **18 passed, 0 failed**.
- Local CI-like benchmark: **5 change scenarios × 3 approaches × 5 repetitions per approach**.
- Local staging-style validation: **9 of 9 checks passed**.
- Main CLI recommendation, synthetic experiment, event demo, and SQLite durable-event demo: successful exit status.
- Unknown/unmapped changed-file fallback: implemented and tested for both hybrid and coverage-only approaches.
- ZIP integrity: verified after packaging.

## Measured local CI-like benchmark

The local benchmark executes real Python assertions selected by each approach and uses a configurable runtime scale to make the fixture experiment repeatable and fast. The durations below are measured wall-clock durations in this environment, not the previous synthetic duration estimates.

| Approach | Mean of case median wall-clock time | Mean time saved vs full | Mean critical-defect recall on fixture oracle |
|---|---:|---:|---:|
| Full regression | 0.352479 sec | 0.00% | 100% |
| Coverage-only | 0.095360 sec | 72.94% | 100% |
| Hybrid selector | 0.138829 sec | 60.62% | 100% |

These measurements are valid for the bundled synthetic CI-like runner only. Runtime scaling is explicitly enabled (`runtime_scale=0.003`) and means the times must not be represented as production e-commerce CI times. The 100% recall applies only to the fixture defect oracle.

Full raw measurements are in `results/local_ci_validation.json`.

## Local staging-style checks

The staging-style script passed all nine checks:

1. Unknown mapping triggers full-suite fallback.
2. Coverage-only unknown mapping triggers full-suite fallback.
3. Out-of-order event is buffered.
4. Pending event survives processor restart.
5. Events commit in sequence order after recovery.
6. Duplicate event ID is idempotent.
7. Conflicting sequence is rejected without overwriting the first pending event.
8. Malformed event envelope is rejected and audited.
9. SQLite backup/restore retains committed state.

Evidence is in `results/local_staging_validation.json` and `results/local_staging_validation.log`. This is a local staging-style simulation, not an external production deployment.

## Usability review evidence

An assistant-led heuristic walkthrough was completed against the documented workflow. It reviewed whether a user can: (a) supply a changed-file diff, (b) inspect selected test IDs and rationale, (c) compare coverage-only with hybrid selection, (d) understand fallback behaviour, and (e) find commands for running tests and experiments. Findings and improvement actions are recorded in `reports/assistant_heuristic_usability_review.md`.

This is a documented assistant heuristic review, **not** fabricated feedback from a human QA/release stakeholder. A human stakeholder session can be added later if the course assessor explicitly requires external human feedback.

## Why the hybrid design is selected

- Full regression is the safest reference baseline but executes every test.
- Coverage-only is fast but ignores historical failures and defect associations.
- Hybrid combines direct/dependency coverage, historical failure signal, and critical-defect associations, with a safety floor and a full-suite fallback when the change cannot be mapped to known test coverage.
- On the local fixture experiment, hybrid saves a mean 60.62% wall-clock time compared with full regression and retains 100% of in-scope critical fixture defects.

## Final conclusion

The self-contained academic prototype package is complete and locally verified. The package now contains measured local execution evidence rather than only estimated runtime figures. Claims are limited to the environment and fixtures actually tested; real company CI and external production certification are not claimed.
