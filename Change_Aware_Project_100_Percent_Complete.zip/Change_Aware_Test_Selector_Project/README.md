# Change-Aware Test Selector for Flash-Sale E-Commerce

**Status:** Complete runnable academic prototype with local CI-like timing evidence, staging-style fault checks, and automated tests.  
**Stack:** Python 3.10+, standard library only. No database or third-party runtime dependencies.

## What this delivers
- Full-regression baseline, coverage-only selector, and hybrid change-aware selector.
- File-diff input, test-to-file coverage map, test execution history, and test-to-defect associations.
- Risk scoring that combines direct coverage, historical failure signal, critical-defect association, and dependency reachability.
- Deterministic recommendation with a safety floor: tests associated with critical defects and tests covering changed files are retained when applicable.
- Event processor that deduplicates event IDs, rejects stale versions, buffers out-of-order events, and drains events in sequence order without mutating committed state twice.
- Three or more edge/failure cases and unit tests.
- Reproducible experiment output and a detailed final report.

## Quick start
From this directory:

```bash
python -m selector.cli recommend --diff data/sample_diff.json --data data
python -m selector.cli experiment --data data --out results/experiment_results.json
python -m unittest discover -s tests -v
python -m selector.cli events --events data/sample_events.json
python -m selector.local_ci_validation --repeats 5 --out results/local_ci_validation.json
python -m selector.staging_validation
```

On Windows, use `py` instead of `python` if that is how Python is installed.

## Input formats
- `data/sample_diff.json`: list of changed paths.
- `data/test_catalog.json`: test IDs, estimated runtime seconds, covered files, critical flag.
- `data/test_history.json`: historical runs and failures.
- `data/defect_associations.json`: defects linked to tests, severity, affected files.
- `data/dependencies.json`: directed file dependency graph (`source` depends on `target`).
- `data/sample_events.json`: event envelopes with `event_id`, `sequence`, `event_type`, and `payload`.

## Scoring and safety
For each candidate test, the selector calculates:
- coverage relevance (directly covers changed files or their dependency neighborhood),
- historical failure rate,
- critical-defect association,
- dependency relevance.

The weighted score is transparent and configurable in `selector/selector.py`. The default selection is not presented as a proof that omitted tests can never detect a defect. A mandatory safety floor retains tests directly covering changed files and tests linked to critical defects when those tests are in scope. The full suite remains available as a fallback for high-risk releases.

## Experiment interpretation
The sample experiment uses **synthetic fixture data** and estimated durations so that results are repeatable. The reported timing is a deterministic model of test runtime, not a benchmark from a live CI system. Replace fixtures with real CI histories, measured runtimes, repository diffs, coverage exports, and confirmed defect links before making production claims.

## Project structure
```
selector/                 implementation
  selector.py             scoring and selection strategies
  events.py               resilient event processor
  experiment.py            baseline comparison and metrics
  cli.py                  command-line interface
data/                     reproducible input fixtures
tests/                    automated tests (including failure states)
results/                   sample experiment output
reports/                   final report (Markdown)
```

## Production deployment checklist
See `reports/final_report.md` for the complete checklist, limitations, monitoring, rollback, and ethics notes.


## Extra completion artifacts
- `.github/workflows/tests.yml`: CI workflow to run unit tests and regenerate the experiment on pushes/pull requests.
- `selector/git_diff.py`: optional adapter to collect changed paths from Git.
- `reports/requirements_traceability.csv`: requirement-to-evidence matrix.
- `reports/acceptance_criteria.md`: local acceptance criteria and external validation checklist.
- `reports/prototype_walkthrough.md`: reproducible walkthrough of the included demo.

**Completion boundary:** The prototype package and local tests are complete. Independent stakeholder validation and real-CI evaluation are external activities and are explicitly not claimed as completed.

## Durability and external validation additions
- `selector/durable_events.py`: SQLite-backed event inbox, transactionally ordered commits, conflict/rejection audit, duplicate protection, and pending-event recovery after process restart.
- `tests/test_durable_events.py`: restart, duplicate-after-restart, conflict, and invalid-event audit tests.
- `selector/ci_benchmark.py`: wall-clock benchmark runner for actual full/coverage/hybrid CI commands. It intentionally does not claim critical-defect recall from timing alone.
- `reports/real_repository_and_ci_validation.md`: commands and evidence checklist for real repository/CI and stakeholder validation.

Run durable event demo:
```bash
python -m selector.cli durable-events --events data/sample_events.json --db results/events.sqlite3
```

Run a real-command timing comparison after replacing the example commands with distinct, valid commands for your repository:
```bash
python -m selector.ci_benchmark --commands data/benchmark_commands.local.json --repeats 5 --out results/real_ci_benchmark.json
```

**Honest completion boundary:** durable local restart recovery is implemented and tested. Real stakeholder feedback, company CI measurements, and production deployment checks cannot be completed without access to a real repository/CI environment and actual reviewers. The runbook identifies these remaining external gates; no fabricated approval or production performance numbers are included.


## Final consolidated audit
See `FINAL_STATUS.md` and `reports/final_audit/FINAL_AUDIT_AND_COMPLETION_PERCENTAGE.md`. The academic prototype deliverable package is complete and locally verified. See `FINAL_STATUS.md` and `reports/final_audit/FINAL_AUDIT_AND_COMPLETION_PERCENTAGE.md` for measured local benchmark results and the exact scope boundary.


## Final local validation added
- Unknown/unmapped changes now trigger full-regression safety fallback for both hybrid and coverage-only strategies.
- `selector/demo_ci_runner.py` runs real Python assertions selected by each approach with a configurable, explicitly synthetic runtime scale.
- `selector/local_ci_validation.py` measures five repeats across five fixture change scenarios for all three approaches. The report includes wall-clock time and critical-defect recall against the fixture oracle.
- `selector/staging_validation.py` performs nine local staging-style checks covering unknown mapping fallback, event ordering, restart recovery, duplicates, conflicts, malformed events, and SQLite backup/restore.
- `reports/assistant_heuristic_usability_review.md` records an assistant-led heuristic walkthrough; it is not represented as human stakeholder feedback.
- `FINAL_STATUS.md` and `reports/final_audit/FINAL_AUDIT_AND_COMPLETION_PERCENTAGE.md` provide the final scope and results.

**Evidence boundary:** The academic prototype package is complete for local demonstration. CI timings are measured on the bundled synthetic runner with runtime scaling, not a real company's CI. The local staging script is not a production deployment.
